<?php
    $server="localhost";
    $user="root";
    $password="";
    $db="resturent";

    $conn = new mysqli($server,$user,$password,$db);

?>